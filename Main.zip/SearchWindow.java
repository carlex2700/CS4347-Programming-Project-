package Main;
import javax.swing.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Vector;
import java.util.List;
import java.lang.*;
import java.sql.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SearchWindow extends JFrame implements ActionListener {
    JFrame frame;
    JFrame frame2 = new JFrame("Results From SQL");
    JTextField search = new JTextField();
    JLabel search_label = new JLabel("Enter a book or author to search for");
    JButton submit;
    JLabel results = new JLabel();
    String submit_collected;
    JLabel nameLabel;
    JTable table;
    DefaultTableModel defaultTableModel;

    SearchWindow(){

        frame = new JFrame();
        frame.setTitle("Search Window");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // closes application by default
           
        //creating object for gridbag
        GridBagLayout bagLayout = new GridBagLayout();
        GridBagConstraints bagConstraints = new GridBagConstraints();
        frame.setSize(500, 300);
        frame.setLayout(bagLayout);
        
        bagConstraints.insets = new Insets(15, 40, 0, 0);//Setting the padding between the components and neighboring components
          
        //Setting the property of JLabel and adding it to the first JFrame
        nameLabel = new JLabel("Enter the Book you wish to look for: ");
        bagConstraints.gridx = 0;
        bagConstraints.gridy = 0;
        frame.add(nameLabel, bagConstraints);
 
        //Setting the property of JTextfield and adding it to the first JFrame
        search = new JTextField(15);
        bagConstraints.gridx = 1;
        bagConstraints.gridy = 0;
        frame.add(search, bagConstraints);
        
        //Setting the property of JButton(Fetch Data) and adding it to the first JFrame
        submit = new JButton("Fetch Data");
        bagConstraints.gridx = 1;
        bagConstraints.gridy = 1;
        bagConstraints.ipadx = 60;
        frame.add(submit, bagConstraints);
        
        frame.setVisible(true);
        frame.validate();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(true);
        
        setLayout(new FlowLayout());
        
        submit.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource() == submit) {
                	submit_collected = search.getText();
                	frame2.setLayout(new FlowLayout());
                	frame2.setSize(1000,500);
                	
                	//setting the properties of jtable and defaulttablemodel
                	defaultTableModel = new DefaultTableModel();
                	table = new JTable(defaultTableModel);
                	table.setPreferredScrollableViewportSize(new Dimension(800,500));
                	table.setFillsViewportHeight(true);
                	frame2.add(new JScrollPane(table));
                	
                	defaultTableModel.addColumn("ISBN10");
                	defaultTableModel.addColumn("ISBN13");
                	defaultTableModel.addColumn("TITLE");
        	
                	try {
                		
                		Class.forName("com.mysql.jdbc.Driver");
                		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?autoReconnect=true", "root", "Thecrow_69");
                		
                		//statement that we tell sql to help find the book we want
                		String sql = "SELECT * FROM book WHERE title LIKE '%" + submit_collected + " %';";
                		PreparedStatement pstmt = conn.prepareStatement(sql);            		
                		ResultSet rs = pstmt.executeQuery();

                		while(rs.next()) {
                			//grabbing the items from the csv 
                			String isbn10 = rs.getString("isbn10");
                            String isbn13 = rs.getString("isbn13");
                            String title = rs.getString("title");
                            
                            defaultTableModel.addRow(new Object[] {isbn10,isbn13,title});
                            DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
                            centerRenderer.setHorizontalAlignment( JLabel.CENTER );
                            table.setDefaultRenderer(String.class, centerRenderer);
                            
                            frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                            frame2.setVisible(true);
                            frame2.validate();   
                		}   		
                	} 
                	catch(Exception e1) {
                		JOptionPane.showMessageDialog(null, e1);
                	}	
                }
            }
        });
    }
   
    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
    }
}