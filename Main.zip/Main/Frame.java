package Main;

import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.BoxLayout;
import javax.swing.Box;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder; 
import java.awt.*;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Frame extends JFrame implements ActionListener{
	JButton bsearch = new JButton("Book Search");
	JButton loan = new JButton("Book Loan");
	JButton fine = new JButton("Book Fine");
	JButton manage = new JButton("Management");
	JButton exit = new JButton("Exit");
	JLabel label = new JLabel("Welcome to the Library");
	
	
	Frame(){
		
		JPanel panel = new JPanel(new GridLayout(6,1,50,25));		
		label.setVerticalAlignment(JLabel.TOP);
		label.setHorizontalAlignment(JLabel.CENTER);
		
		panel.add(label);
		panel.add(bsearch);
		panel.add(loan);
		panel.add(manage);
		panel.add(fine);
		panel.add(exit);
		
		bsearch.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(e.getSource()== bsearch ) {
					SearchWindow bookSearch = new SearchWindow();
				}
			}
		});
		
		
		loan.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(e.getSource()== loan ) {
					//LoanWindow loan_window = new LoanWindow();
				}
			}
			
		});
		
		manage.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(e.getSource() == manage ) {
					//ManageWindow mgmt_window = new ManageWindow();
				}	
			}			
		});
		
		exit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JFrame frame = new JFrame();
				if(JOptionPane.showConfirmDialog(frame, "Are you sure you want to exit?","EXIT", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION){
					System.exit(0);
				}				
			}
		});
		
		loan.addActionListener(this);
		this.setTitle("Main");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(true);
		this.setSize(1000,1000);
		this.add(panel);
		this.pack();
		this.setVisible(true);		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {	
	}	
}
