package Main;
import javax.swing.*;

public class Main {
	public static void main(String[] args) {	
	    Frame library = new Frame();    
	}
}